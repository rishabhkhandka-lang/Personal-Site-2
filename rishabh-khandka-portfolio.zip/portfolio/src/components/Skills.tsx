"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { skillCategories, skillCloud } from "@/lib/data";

function SkillBar({ name, level, delay }: { name: string; level: number; delay: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });

  return (
    <div ref={ref} className="mb-5">
      <div className="flex justify-between mb-2">
        <span className="text-sm font-body text-porcelain">{name}</span>
        <span className="text-xs font-mono text-smoke">{level}%</span>
      </div>
      <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={inView ? { width: `${level}%` } : { width: 0 }}
          transition={{ duration: 1.2, delay, ease: [0.22, 1, 0.36, 1] }}
          className="h-full rounded-full bg-gradient-to-r from-electric to-violet"
        />
      </div>
    </div>
  );
}

export default function Skills() {
  return (
    <section id="skills" className="section-pad relative bg-void overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="eyebrow mb-4"
        >
          Skills
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="font-display text-3xl md:text-5xl font-semibold text-porcelain mb-14 max-w-2xl"
        >
          Range, on and off the stage
        </motion.h2>

        <div className="grid md:grid-cols-2 gap-x-16 gap-y-12 mb-20">
          {skillCategories.map((cat, ci) => (
            <motion.div
              key={cat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: ci * 0.1 }}
              className="glass rounded-2xl p-7"
            >
              <h3 className="font-mono text-xs uppercase tracking-widest text-electric-soft mb-6">
                {cat.label}
              </h3>
              {cat.skills.map((s, i) => (
                <SkillBar key={s.name} name={s.name} level={s.level} delay={i * 0.08} />
              ))}
            </motion.div>
          ))}
        </div>

        {/* Floating tech cloud */}
        <div className="relative">
          <p className="eyebrow mb-8 text-center">Toolkit</p>
          <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
            {skillCloud.map((tech, i) => (
              <motion.span
                key={tech}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ delay: (i % 8) * 0.05, duration: 0.4 }}
                whileHover={{
                  scale: 1.1,
                  boxShadow: "0 0 24px rgba(61,116,255,0.35)",
                }}
                data-cursor-hover
                className="glass px-5 py-2.5 rounded-full text-sm font-body text-porcelain cursor-default animate-float"
                style={{ animationDelay: `${(i % 6) * 0.4}s` }}
              >
                {tech}
              </motion.span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
