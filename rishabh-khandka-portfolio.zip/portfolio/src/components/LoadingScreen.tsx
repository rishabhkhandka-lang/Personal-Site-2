"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setDone(true);
      return;
    }
    const interval = setInterval(() => {
      setProgress((p) => {
        const next = p + (100 - p) * 0.18 + 1.2;
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(() => setDone(true), 350);
          return 100;
        }
        return next;
      });
    }, 60);
    return () => clearInterval(interval);
  }, []);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          exit={{
            opacity: 0,
            transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
          }}
          className="fixed inset-0 z-[100] bg-void flex flex-col items-center justify-center"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="font-display text-5xl font-semibold text-gradient mb-8"
          >
            RK
          </motion.div>
          <div className="w-56 h-px bg-white/10 overflow-hidden rounded-full">
            <motion.div
              className="h-full bg-gradient-to-r from-electric to-violet"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>
          <p className="mt-4 font-mono text-xs tracking-widest text-smoke">
            {Math.floor(Math.min(progress, 100))}%
          </p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
