"use client";

import { motion } from "framer-motion";
import { Linkedin, Mail, ArrowUp } from "lucide-react";
import { profile } from "@/lib/data";

export default function Footer() {
  const scrollTop = () => {
    const lenis = (window as any).__lenis;
    if (lenis) lenis.scrollTo(0);
    else window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="relative bg-charcoal border-t border-white/5 pt-16 pb-8 overflow-hidden">
      <div className="absolute inset-0 bg-aurora-gradient opacity-30 pointer-events-none" />
      <div className="relative mx-auto max-w-7xl px-6 md:px-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-10 mb-14">
          <div>
            <h3 className="font-display text-3xl md:text-4xl font-semibold text-gradient mb-3">
              Rishabh S. Khandka
            </h3>
            <p className="text-mist max-w-md text-sm leading-relaxed">
              {profile.subtitle}
            </p>
          </div>

          <div className="flex gap-3">
            <a
              href={`mailto:${profile.email}`}
              data-cursor-hover
              aria-label="Email"
              className="w-12 h-12 rounded-full glass flex items-center justify-center hover:shadow-glow transition-shadow"
            >
              <Mail size={17} className="text-porcelain" />
            </a>
            <a
              href={profile.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              data-cursor-hover
              aria-label="LinkedIn"
              className="w-12 h-12 rounded-full glass flex items-center justify-center hover:shadow-glow transition-shadow"
            >
              <Linkedin size={17} className="text-porcelain" />
            </a>
          </div>
        </div>

        <div className="flex flex-col-reverse md:flex-row justify-between items-center gap-4 pt-8 border-t border-white/5">
          <p className="text-xs text-smoke font-mono">
            © {new Date().getFullYear()} Rishabh S. Khandka. All rights reserved.
          </p>

          <motion.button
            onClick={scrollTop}
            data-cursor-hover
            whileHover={{ y: -3 }}
            aria-label="Back to top"
            className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-mist hover:text-porcelain transition-colors"
          >
            Back to top
            <span className="w-8 h-8 rounded-full glass flex items-center justify-center">
              <ArrowUp size={13} />
            </span>
          </motion.button>
        </div>
      </div>
    </footer>
  );
}
