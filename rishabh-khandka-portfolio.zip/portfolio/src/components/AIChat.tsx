"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Send, Sparkles } from "lucide-react";
import {
  profile,
  experience,
  achievements,
  certifications,
  skillCategories,
  pillars,
} from "@/lib/data";

type Message = { role: "user" | "bot"; text: string };

const SUGGESTIONS = [
  "What has Rishabh achieved?",
  "Tell me about his certifications",
  "What are his skills?",
  "How can I contact him?",
];

function buildAnswer(raw: string): string {
  const q = raw.toLowerCase();

  if (/(hi|hello|hey)\b/.test(q) && q.length < 12) {
    return `Hey! I'm Ask Rishabh AI — I can answer questions about ${profile.name}'s achievements, certifications, skills, experience, and how to get in touch. What would you like to know?`;
  }

  if (/(certif|course|credential)/.test(q)) {
    const list = certifications
      .map((c) => `• ${c.title} — ${c.issuer}`)
      .join("\n");
    return `Rishabh holds ${certifications.length} certifications spanning AI, marketing, and finance:\n\n${list}\n\nHe completed courses from OpenAI Academy, Anthropic, HubSpot, Semrush, and J.P. Morgan (via Forage).`;
  }

  if (/(achiev|award|win|won|trophy|debate.*win)/.test(q)) {
    const list = achievements
      .slice(0, 5)
      .map((a) => `• ${a.title} — ${a.event} (${a.year})`)
      .join("\n");
    return `A few highlights:\n\n${list}\n\nHe's also the first-ever Head Boy in Ann Mary School's history since 1985, honoured as "Voice of Excellence of the School."`;
  }

  if (/(skill|tech|stack|tool|programming|language)/.test(q)) {
    const list = skillCategories
      .map((c) => `${c.label}: ${c.skills.map((s) => s.name).join(", ")}`)
      .join("\n");
    return `Rishabh's toolkit spans technical and leadership skills:\n\n${list}`;
  }

  if (/(experience|work|volunteer|leadership|head boy|role)/.test(q)) {
    const list = experience
      .map((e) => `• ${e.title} — ${e.org} (${e.period})`)
      .join("\n");
    return `His experience so far:\n\n${list}`;
  }

  if (/(education|school|study|studied|college|university)/.test(q)) {
    return `Rishabh recently completed Class XII at Ann Mary School, Dehradun, where he served as the school's first-ever Head Boy since its founding in 1985. He's currently exploring career paths that combine discipline and strategy — from defence to engineering.`;
  }

  if (/(career|future|plan|goal|defence|engineer)/.test(q)) {
    return `Rishabh is exploring career paths that combine discipline and strategy — from defence to engineering. He's still figuring out exactly where he fits, and he's genuinely okay with that being part of the process.`;
  }

  if (/(contact|email|reach|linkedin|hire|connect)/.test(q)) {
    return `You can reach Rishabh at ${profile.email} or connect on LinkedIn. There's also a contact form at the bottom of this page — I'd recommend using it, he actually reads these.`;
  }

  if (/(guitar|music|hobby|hobbies)/.test(q)) {
    return `Outside the spotlight of competition, Rishabh plays guitar. It's part of how he balances the high-intensity world of competitive debate and public speaking.`;
  }

  if (/(who (are|is) you|what (are|is) you|ai\b)/.test(q)) {
    return `I'm Ask Rishabh AI — a small assistant built into this portfolio to answer questions about Rishabh's background, achievements, and how to get in touch. Ask me anything!`;
  }

  return `I don't have a specific answer for that yet, but I can tell you about Rishabh's achievements, certifications, skills, experience, education, or how to contact him. Try one of the suggestions below!`;
}

export default function AIChat() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "bot",
      text: `Hi! I'm Ask Rishabh AI. Ask me about ${profile.name}'s projects, achievements, skills, education, career, or certifications.`,
    },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, typing]);

  const send = (text: string) => {
    if (!text.trim()) return;
    setMessages((m) => [...m, { role: "user", text }]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setMessages((m) => [...m, { role: "bot", text: buildAnswer(text) }]);
      setTyping(false);
    }, 650 + Math.random() * 500);
  };

  return (
    <>
      <motion.button
        onClick={() => setOpen((v) => !v)}
        data-cursor-hover
        aria-label="Open Ask Rishabh AI chatbot"
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2 rounded-full bg-gradient-to-r from-electric to-violet px-5 py-3.5 shadow-glow text-white font-body text-sm font-medium"
      >
        {open ? <X size={18} /> : <Sparkles size={18} />}
        <span className="hidden sm:inline">
          {open ? "Close" : "Ask Rishabh AI"}
        </span>
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.96 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="fixed bottom-24 right-6 z-40 w-[92vw] max-w-sm h-[520px] glass-strong rounded-3xl flex flex-col overflow-hidden shadow-glow"
          >
            <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-electric to-violet flex items-center justify-center">
                <Sparkles size={14} className="text-white" />
              </div>
              <div>
                <p className="text-sm font-display font-semibold text-porcelain">
                  Ask Rishabh AI
                </p>
                <p className="text-[11px] text-mist">Usually replies instantly</p>
              </div>
            </div>

            <div
              ref={scrollRef}
              className="flex-1 overflow-y-auto px-5 py-4 space-y-4"
            >
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm whitespace-pre-line leading-relaxed ${
                      m.role === "user"
                        ? "bg-gradient-to-r from-electric to-violet text-white rounded-br-sm"
                        : "glass text-porcelain rounded-bl-sm"
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
              {typing && (
                <div className="flex justify-start">
                  <div className="glass rounded-2xl rounded-bl-sm px-4 py-3 flex gap-1">
                    {[0, 1, 2].map((d) => (
                      <motion.span
                        key={d}
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1, repeat: Infinity, delay: d * 0.2 }}
                        className="w-1.5 h-1.5 rounded-full bg-mist"
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>

            {messages.length < 3 && (
              <div className="px-5 pb-2 flex flex-wrap gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="text-xs px-3 py-1.5 rounded-full glass text-mist hover:text-porcelain transition-colors"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
              className="flex items-center gap-2 p-4 border-t border-white/10"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about projects, skills, contact..."
                className="flex-1 bg-white/5 rounded-full px-4 py-2.5 text-sm text-porcelain placeholder:text-smoke outline-none focus:ring-1 focus:ring-electric/50"
              />
              <button
                type="submit"
                aria-label="Send message"
                data-cursor-hover
                className="w-10 h-10 shrink-0 rounded-full bg-gradient-to-r from-electric to-violet flex items-center justify-center text-white"
              >
                <Send size={15} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
