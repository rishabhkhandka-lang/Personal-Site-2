"use client";

import { useRef, useState, MouseEvent } from "react";
import { motion } from "framer-motion";
import Image from "next/image";
import { certifications, Certification } from "@/lib/data";
import clsx from "clsx";

const colorMap: Record<Certification["color"], string> = {
  openai: "from-cyan-400/40 to-blue-500/30",
  anthropic: "from-lime-300/30 to-green-600/25",
  hubspot: "from-orange-400/35 to-rose-400/25",
  semrush: "from-violet-400/35 to-fuchsia-500/25",
  jpmorgan: "from-blue-600/35 to-blue-900/30",
};

function CertCard({ cert, i }: { cert: Certification; i: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: py * -10, y: px * 12 });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ delay: (i % 4) * 0.08, duration: 0.6 }}
      style={{ perspective: 1000 }}
    >
      <div
        ref={ref}
        onMouseMove={handleMove}
        onMouseLeave={() => setTilt({ x: 0, y: 0 })}
        data-cursor-hover
        className="group relative rounded-2xl overflow-hidden gradient-border shimmer-sweep"
        style={{
          transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
          transition: "transform 0.25s ease-out",
          transformStyle: "preserve-3d",
        }}
      >
        <div
          className={clsx(
            "absolute -inset-8 opacity-0 group-hover:opacity-100 blur-3xl bg-gradient-to-br transition-opacity duration-500",
            colorMap[cert.color]
          )}
        />
        <div className="relative glass-strong p-5">
          <div className="relative rounded-xl overflow-hidden mb-4 aspect-[4/3] bg-black/30">
            <Image
              src={cert.image}
              alt={`${cert.title} certificate`}
              fill
              className="object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 via-transparent to-transparent" />
          </div>
          <p className="font-mono text-[11px] tracking-widest uppercase text-electric-soft mb-1">
            {cert.issuer}
          </p>
          <h3 className="font-display text-lg font-semibold text-porcelain leading-snug mb-2">
            {cert.title}
          </h3>
          <p className="text-sm text-mist leading-relaxed">
            {cert.description}
          </p>
          {cert.date && (
            <p className="mt-3 text-xs font-mono text-smoke">{cert.date}</p>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export default function Certifications() {
  return (
    <section id="certifications" className="section-pad relative bg-void">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="eyebrow mb-4"
        >
          Certifications
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="font-display text-3xl md:text-5xl font-semibold text-porcelain mb-14 max-w-2xl"
        >
          Credentialed, self-taught, and always learning
        </motion.h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {certifications.map((cert, i) => (
            <CertCard cert={cert} i={i} key={cert.id} />
          ))}
        </div>
      </div>
    </section>
  );
}
