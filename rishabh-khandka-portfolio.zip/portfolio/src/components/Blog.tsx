"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Mail } from "lucide-react";
import MagneticButton from "./MagneticButton";

const POSTS = [
  {
    title: "What Two Years at the Podium Taught Me About Leadership",
    excerpt:
      "Being the first Head Boy in a school's 40-year history means writing the rulebook as you go. Here's what that actually looked like.",
    tag: "Leadership",
    readTime: "6 min",
  },
  {
    title: "Debate Isn't About Winning Arguments — It's About Building Them",
    excerpt:
      "Case-building, rebuttal structure, and the quiet research work behind every 90-second speech that looks effortless.",
    tag: "Public Speaking",
    readTime: "5 min",
  },
  {
    title: "Why I'm Learning AI Fluency Before I Need It",
    excerpt:
      "Certifications from OpenAI and Anthropic, and what studying applied AI taught a debater about clear thinking.",
    tag: "AI",
    readTime: "4 min",
  },
];

export default function Blog() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubmitted(true);
  };

  const [featured, ...rest] = POSTS;

  return (
    <section id="blog" className="section-pad relative bg-charcoal">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="eyebrow mb-4"
        >
          Writing
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="font-display text-3xl md:text-5xl font-semibold text-porcelain mb-14 max-w-2xl"
        >
          Thoughts from the podium
        </motion.h2>

        <div className="grid lg:grid-cols-[1.3fr_1fr] gap-8 mb-8">
          {/* Featured */}
          <motion.article
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            whileHover={{ y: -6 }}
            data-cursor-hover
            className="group relative rounded-3xl overflow-hidden gradient-border p-8 md:p-10 flex flex-col justify-end min-h-[360px] bg-gradient-to-br from-graphite to-charcoal"
          >
            <div className="absolute inset-0 bg-aurora-gradient opacity-60" />
            <span className="relative eyebrow mb-4 w-fit px-3 py-1 rounded-full glass">
              {featured.tag}
            </span>
            <h3 className="relative font-display text-2xl md:text-3xl font-semibold text-porcelain mb-3 max-w-lg">
              {featured.title}
            </h3>
            <p className="relative text-mist text-sm md:text-base leading-relaxed max-w-lg mb-4">
              {featured.excerpt}
            </p>
            <div className="relative flex items-center gap-2 text-electric-soft text-sm font-medium">
              Read article <ArrowUpRight size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </div>
          </motion.article>

          {/* Rest + newsletter */}
          <div className="flex flex-col gap-6">
            {rest.map((post, i) => (
              <motion.article
                key={post.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ x: 4 }}
                data-cursor-hover
                className="group glass rounded-2xl p-6 flex-1 shimmer-sweep"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-mono uppercase tracking-widest text-electric-soft">
                    {post.tag}
                  </span>
                  <span className="text-[11px] text-smoke">{post.readTime}</span>
                </div>
                <h3 className="font-display text-base font-semibold text-porcelain mb-2 leading-snug">
                  {post.title}
                </h3>
                <p className="text-xs text-mist leading-relaxed">
                  {post.excerpt}
                </p>
              </motion.article>
            ))}
          </div>
        </div>

        {/* Newsletter */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass-strong rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-6"
        >
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Mail size={16} className="text-electric-soft" />
              <span className="eyebrow">Newsletter</span>
            </div>
            <h3 className="font-display text-xl md:text-2xl font-semibold text-porcelain">
              Occasional dispatches. No spam.
            </h3>
          </div>

          {submitted ? (
            <p className="text-electric-soft font-medium text-sm">
              You&apos;re in — thanks for subscribing.
            </p>
          ) : (
            <form
              onSubmit={handleSubmit}
              className="flex w-full md:w-auto gap-3"
            >
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                className="flex-1 md:w-72 bg-white/5 rounded-full px-5 py-3 text-sm text-porcelain placeholder:text-smoke outline-none focus:ring-1 focus:ring-electric/50"
              />
              <MagneticButton as="button" variant="primary">
                Subscribe
              </MagneticButton>
            </form>
          )}
        </motion.div>
      </div>
    </section>
  );
}
