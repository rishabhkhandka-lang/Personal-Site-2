"use client";

import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { ArrowDown, ArrowRight, FileDown } from "lucide-react";
import Image from "next/image";
import MagneticButton from "./MagneticButton";
import { profile } from "@/lib/data";

const ArgumentWeb = dynamic(() => import("./ArgumentWeb"), { ssr: false });

const ROLES = [
  "Founding Head Boy.",
  "Award-Winning Debater.",
  "Public Speaker.",
  "Strategic Thinker.",
];

function useTypewriter(words: string[]) {
  const [text, setText] = useState("");
  const [wordIndex, setWordIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = words[wordIndex % words.length];
    const speed = deleting ? 35 : 65;
    const pause = deleting ? 400 : 1600;

    if (!deleting && text === current) {
      const t = setTimeout(() => setDeleting(true), pause);
      return () => clearTimeout(t);
    }
    if (deleting && text === "") {
      setDeleting(false);
      setWordIndex((i) => i + 1);
      return;
    }

    const t = setTimeout(() => {
      setText((prev) =>
        deleting ? current.slice(0, prev.length - 1) : current.slice(0, prev.length + 1)
      );
    }, speed);
    return () => clearTimeout(t);
  }, [text, deleting, wordIndex, words]);

  return text;
}

export default function Hero() {
  const typed = useTypewriter(ROLES);
  const containerRef = useRef<HTMLDivElement>(null);

  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const springX = useSpring(mx, { stiffness: 60, damping: 20 });
  const springY = useSpring(my, { stiffness: 60, damping: 20 });

  const portraitRotateX = useTransform(springY, [-0.5, 0.5], [6, -6]);
  const portraitRotateY = useTransform(springX, [-0.5, 0.5], [-8, 8]);
  const glowX = useTransform(springX, [-0.5, 0.5], ["30%", "70%"]);
  const glowY = useTransform(springY, [-0.5, 0.5], ["30%", "70%"]);

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      mx.set((e.clientX - rect.left) / rect.width - 0.5);
      my.set((e.clientY - rect.top) / rect.height - 0.5);
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, [mx, my]);

  const scrollToAbout = () => {
    const el = document.querySelector("#about");
    const lenis = (window as any).__lenis;
    if (lenis && el) lenis.scrollTo(el);
    else el?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="hero"
      ref={containerRef}
      className="relative min-h-[100svh] w-full overflow-hidden bg-void flex items-center"
    >
      {/* Aurora + mouse spotlight */}
      <div className="absolute inset-0 bg-aurora-gradient pointer-events-none" />
      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(600px circle at ${glowX} ${glowY}, rgba(61,116,255,0.14), transparent 70%)`,
        }}
      />

      <ArgumentWeb />

      <div className="relative z-10 mx-auto max-w-7xl w-full px-6 md:px-10 grid md:grid-cols-[1.15fr_0.85fr] gap-12 items-center pt-28 pb-20">
        {/* Text column */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
        >
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="eyebrow mb-6"
          >
            PORTFOLIO — 2026
          </motion.p>

          <h1 className="font-display font-semibold leading-[0.95] text-[clamp(2.75rem,7vw,6rem)] text-porcelain">
            <span className="block overflow-hidden">
              <motion.span
                initial={{ y: "110%" }}
                animate={{ y: 0 }}
                transition={{ duration: 0.9, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
                className="block"
              >
                Rishabh S.
              </motion.span>
            </span>
            <span className="block overflow-hidden">
              <motion.span
                initial={{ y: "110%" }}
                animate={{ y: 0 }}
                transition={{ duration: 0.9, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
                className="block text-gradient"
              >
                Khandka
              </motion.span>
            </span>
          </h1>

          <div className="mt-7 h-8 font-mono text-base md:text-lg text-electric-soft">
            {typed}
            <span className="inline-block w-[2px] h-5 bg-electric-soft ml-1 animate-pulse align-middle" />
          </div>

          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.7 }}
            className="mt-6 max-w-xl text-mist text-base md:text-lg leading-relaxed"
          >
            {profile.tagline}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.7 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <MagneticButton href="#contact" variant="primary">
              Get in touch <ArrowRight size={16} />
            </MagneticButton>
            <MagneticButton href="/resume.pdf" variant="secondary" target="_blank">
              Resume <FileDown size={16} />
            </MagneticButton>
          </motion.div>
        </motion.div>

        {/* Portrait column */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto w-full max-w-sm"
          style={{ perspective: 1200 }}
        >
          <motion.div
            style={{ rotateX: portraitRotateX, rotateY: portraitRotateY }}
            className="relative rounded-[2rem] overflow-hidden gradient-border shadow-glow"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-void/80 via-transparent to-transparent z-10" />
            <Image
              src="/images/hero-portrait.webp"
              alt="Rishabh S. Khandka speaking at a podium"
              width={640}
              height={800}
              priority
              className="w-full h-[440px] md:h-[520px] object-cover object-top"
            />
          </motion.div>
          <div className="absolute -bottom-6 -left-6 w-28 h-28 rounded-2xl bg-gradient-to-br from-electric to-violet opacity-20 blur-2xl animate-float" />
          <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full bg-violet opacity-20 blur-2xl animate-float-delayed" />
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.button
        onClick={scrollToAbout}
        aria-label="Scroll to About section"
        data-cursor-hover
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-mist"
      >
        <span className="eyebrow">Scroll</span>
        <motion.span
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        >
          <ArrowDown size={16} />
        </motion.span>
      </motion.button>
    </section>
  );
}
