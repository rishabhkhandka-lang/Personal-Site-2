"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { experience } from "@/lib/data";

export default function Experience() {
  return (
    <section id="experience" className="section-pad relative bg-charcoal">
      <div className="mx-auto max-w-5xl px-6 md:px-10">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="eyebrow mb-4 text-center"
        >
          Experience
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="font-display text-3xl md:text-5xl font-semibold text-center text-porcelain mb-20"
        >
          Where the leading happened
        </motion.h2>

        <div className="relative">
          {/* spine */}
          <div className="absolute left-[15px] md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-electric/60 via-violet/40 to-transparent md:-translate-x-1/2" />

          <div className="space-y-16">
            {experience.map((item, i) => {
              const leftSide = i % 2 === 0;
              return (
                <div
                  key={item.id}
                  className="relative grid md:grid-cols-2 gap-8 md:gap-16"
                >
                  {/* dot */}
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                    className="absolute left-0 md:left-1/2 top-1.5 w-[31px] h-[31px] md:-translate-x-1/2 rounded-full bg-void border-2 border-electric flex items-center justify-center z-10"
                  >
                    <div className="w-2.5 h-2.5 rounded-full bg-gradient-to-br from-electric to-violet" />
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, x: leftSide ? -30 : 30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, margin: "-80px" }}
                    transition={{ duration: 0.7 }}
                    whileHover={{ y: -4 }}
                    className={`pl-12 md:pl-0 ${
                      leftSide ? "md:col-start-1" : "md:col-start-2"
                    }`}
                  >
                    <div className="glass rounded-2xl p-6 md:p-8 shimmer-sweep">
                      <span className="font-mono text-xs text-electric-soft tracking-widest uppercase">
                        {item.period}
                      </span>
                      <h3 className="font-display text-xl md:text-2xl font-semibold text-porcelain mt-2">
                        {item.title}
                      </h3>
                      <p className="text-sm text-violet-soft font-medium mt-1 mb-4">
                        {item.org}
                      </p>
                      <p className="text-mist text-sm leading-relaxed mb-4">
                        {item.summary}
                      </p>
                      <ul className="space-y-2">
                        {item.points.slice(0, 4).map((pt, idx) => (
                          <li
                            key={idx}
                            className="flex gap-2 text-sm text-mist/90 leading-relaxed"
                          >
                            <span className="text-electric-soft mt-1.5 block w-1 h-1 rounded-full bg-electric-soft shrink-0" />
                            {pt}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
