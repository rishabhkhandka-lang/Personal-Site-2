"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Linkedin, Mail, FileDown, Send, CheckCircle2 } from "lucide-react";
import MagneticButton from "./MagneticButton";
import { profile } from "@/lib/data";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    const subject = encodeURIComponent(`Portfolio contact from ${form.name}`);
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name} (${form.email})`);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
    setSent(true);
  };

  return (
    <section id="contact" className="section-pad relative bg-void overflow-hidden">
      <div className="absolute inset-0 bg-aurora-gradient opacity-70 pointer-events-none" />
      <div className="relative mx-auto max-w-6xl px-6 md:px-10">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="eyebrow mb-4 text-center"
        >
          Contact
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="font-display text-3xl md:text-6xl font-semibold text-center text-porcelain mb-6"
        >
          Let&apos;s start a <span className="text-gradient-accent">conversation</span>
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-mist text-center max-w-xl mx-auto mb-16"
        >
          Open to conversations about leadership, debate, opportunities, or anything in between.
        </motion.p>

        <div className="grid md:grid-cols-[1fr_1.2fr] gap-10">
          {/* Info card */}
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-strong rounded-3xl p-8 flex flex-col justify-between"
          >
            <div className="space-y-6">
              <a
                href={`mailto:${profile.email}`}
                data-cursor-hover
                className="flex items-center gap-4 group"
              >
                <div className="w-11 h-11 rounded-full glass flex items-center justify-center group-hover:shadow-glow transition-shadow">
                  <Mail size={17} className="text-electric-soft" />
                </div>
                <div>
                  <p className="text-xs text-smoke font-mono uppercase tracking-widest">Email</p>
                  <p className="text-sm text-porcelain">{profile.email}</p>
                </div>
              </a>

              <a
                href={profile.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                data-cursor-hover
                className="flex items-center gap-4 group"
              >
                <div className="w-11 h-11 rounded-full glass flex items-center justify-center group-hover:shadow-glow transition-shadow">
                  <Linkedin size={17} className="text-electric-soft" />
                </div>
                <div>
                  <p className="text-xs text-smoke font-mono uppercase tracking-widest">LinkedIn</p>
                  <p className="text-sm text-porcelain">Rishabh S. Khandka</p>
                </div>
              </a>
            </div>

            <div className="mt-10 pt-8 border-t border-white/10">
              <p className="text-xs text-smoke font-mono uppercase tracking-widest mb-4">
                Resume
              </p>
              <MagneticButton href="/resume.pdf" variant="secondary" target="_blank" className="w-full justify-center">
                Download Resume <FileDown size={16} />
              </MagneticButton>
            </div>
          </motion.div>

          {/* Form */}
          <motion.form
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            onSubmit={handleSubmit}
            className="glass-strong rounded-3xl p-8 space-y-5"
          >
            <div>
              <label className="text-xs font-mono uppercase tracking-widest text-smoke mb-2 block">
                Name
              </label>
              <input
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-white/5 rounded-xl px-4 py-3 text-sm text-porcelain placeholder:text-smoke outline-none focus:ring-1 focus:ring-electric/50"
                placeholder="Your name"
              />
            </div>
            <div>
              <label className="text-xs font-mono uppercase tracking-widest text-smoke mb-2 block">
                Email
              </label>
              <input
                required
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full bg-white/5 rounded-xl px-4 py-3 text-sm text-porcelain placeholder:text-smoke outline-none focus:ring-1 focus:ring-electric/50"
                placeholder="you@email.com"
              />
            </div>
            <div>
              <label className="text-xs font-mono uppercase tracking-widest text-smoke mb-2 block">
                Message
              </label>
              <textarea
                required
                rows={4}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full bg-white/5 rounded-xl px-4 py-3 text-sm text-porcelain placeholder:text-smoke outline-none focus:ring-1 focus:ring-electric/50 resize-none"
                placeholder="What's on your mind?"
              />
            </div>
            <MagneticButton as="button" variant="primary" className="w-full justify-center">
              {sent ? (
                <>
                  Opening your mail client <CheckCircle2 size={16} />
                </>
              ) : (
                <>
                  Send message <Send size={15} />
                </>
              )}
            </MagneticButton>
          </motion.form>
        </div>
      </div>
    </section>
  );
}
