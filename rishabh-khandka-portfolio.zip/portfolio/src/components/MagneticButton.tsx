"use client";

import { useRef, useState, ReactNode, MouseEvent } from "react";
import { motion } from "framer-motion";
import clsx from "clsx";

type Props = {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost";
  className?: string;
  as?: "a" | "button";
  target?: string;
};

export default function MagneticButton({
  children,
  href,
  onClick,
  variant = "primary",
  className,
  as,
  target,
}: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    setPos({ x: x * 0.35, y: y * 0.35 });
  };

  const reset = () => setPos({ x: 0, y: 0 });

  const base =
    "relative inline-flex items-center justify-center gap-2 rounded-full px-7 py-3.5 font-body font-medium text-sm tracking-wide transition-colors duration-300";
  const variants = {
    primary:
      "bg-gradient-to-r from-electric to-violet text-white shadow-glow hover:shadow-glow-violet",
    secondary: "glass text-porcelain hover:border-electric/50",
    ghost: "text-porcelain/80 hover:text-white",
  };

  const Tag = (as === "button" ? "button" : "a") as any;

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={reset}
      animate={{ x: pos.x, y: pos.y }}
      transition={{ type: "spring", stiffness: 150, damping: 12, mass: 0.4 }}
      className="magnetic-btn inline-block"
      data-cursor-hover
    >
      <Tag
        href={as === "button" ? undefined : href}
        onClick={onClick}
        target={target}
        className={clsx(base, variants[variant], className)}
      >
        {children}
      </Tag>
    </motion.div>
  );
}
