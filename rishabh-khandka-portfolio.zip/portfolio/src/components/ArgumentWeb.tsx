"use client";

import { useRef, useMemo, useState, useEffect } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

/**
 * ArgumentWeb — the site's signature background element.
 * A field of connected nodes that drift and link based on proximity,
 * representing the act of connecting ideas, people, and arguments —
 * a visual metaphor for debate, leadership, and strategic thinking,
 * rather than a generic particle field.
 */

const NODE_COUNT = 90;
const CONNECT_DIST = 2.6;

function Web({ mouse }: { mouse: React.MutableRefObject<[number, number]> }) {
  const pointsRef = useRef<THREE.Points>(null);
  const lineRef = useRef<THREE.LineSegments>(null);
  const { viewport } = useThree();

  const positions = useMemo(() => {
    const arr = new Float32Array(NODE_COUNT * 3);
    for (let i = 0; i < NODE_COUNT; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 16;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 9;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 6;
    }
    return arr;
  }, []);

  const velocities = useMemo(() => {
    return new Array(NODE_COUNT).fill(0).map(() => [
      (Math.random() - 0.5) * 0.004,
      (Math.random() - 0.5) * 0.004,
      (Math.random() - 0.5) * 0.002,
    ]);
  }, []);

  const geomRef = useRef<THREE.BufferGeometry>(null);
  const lineGeomRef = useRef<THREE.BufferGeometry>(null);

  const maxLines = NODE_COUNT * 8;
  const linePositions = useMemo(
    () => new Float32Array(maxLines * 2 * 3),
    []
  );

  useFrame((state) => {
    const posAttr = geomRef.current?.attributes.position as
      | THREE.BufferAttribute
      | undefined;
    if (!posAttr) return;

    const arr = posAttr.array as Float32Array;

    for (let i = 0; i < NODE_COUNT; i++) {
      arr[i * 3] += velocities[i][0];
      arr[i * 3 + 1] += velocities[i][1];
      arr[i * 3 + 2] += velocities[i][2];

      if (Math.abs(arr[i * 3]) > 8) velocities[i][0] *= -1;
      if (Math.abs(arr[i * 3 + 1]) > 4.5) velocities[i][1] *= -1;
      if (Math.abs(arr[i * 3 + 2]) > 3) velocities[i][2] *= -1;
    }

    // gentle mouse parallax on whole group
    const t = state.clock.elapsedTime;
    if (pointsRef.current) {
      pointsRef.current.rotation.y = mouse.current[0] * 0.15 + Math.sin(t * 0.05) * 0.05;
      pointsRef.current.rotation.x = mouse.current[1] * 0.08;
    }
    if (lineRef.current) {
      lineRef.current.rotation.y = mouse.current[0] * 0.15 + Math.sin(t * 0.05) * 0.05;
      lineRef.current.rotation.x = mouse.current[1] * 0.08;
    }

    posAttr.needsUpdate = true;

    // recompute connections
    let lineIdx = 0;
    const lineArr = lineGeomRef.current?.attributes.position
      .array as Float32Array;
    if (lineArr) {
      for (let i = 0; i < NODE_COUNT && lineIdx < maxLines; i++) {
        for (let j = i + 1; j < NODE_COUNT && lineIdx < maxLines; j++) {
          const dx = arr[i * 3] - arr[j * 3];
          const dy = arr[i * 3 + 1] - arr[j * 3 + 1];
          const dz = arr[i * 3 + 2] - arr[j * 3 + 2];
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (dist < CONNECT_DIST) {
            lineArr[lineIdx * 6] = arr[i * 3];
            lineArr[lineIdx * 6 + 1] = arr[i * 3 + 1];
            lineArr[lineIdx * 6 + 2] = arr[i * 3 + 2];
            lineArr[lineIdx * 6 + 3] = arr[j * 3];
            lineArr[lineIdx * 6 + 4] = arr[j * 3 + 1];
            lineArr[lineIdx * 6 + 5] = arr[j * 3 + 2];
            lineIdx++;
          }
        }
      }
      // zero out remaining
      for (let k = lineIdx; k < maxLines; k++) {
        lineArr[k * 6] = 0;
        lineArr[k * 6 + 1] = 0;
        lineArr[k * 6 + 2] = 0;
        lineArr[k * 6 + 3] = 0;
        lineArr[k * 6 + 4] = 0;
        lineArr[k * 6 + 5] = 0;
      }
      lineGeomRef.current!.attributes.position.needsUpdate = true;
      lineGeomRef.current!.setDrawRange(0, lineIdx * 2);
    }
  });

  return (
    <group>
      <points ref={pointsRef}>
        <bufferGeometry ref={geomRef}>
          <bufferAttribute
            attach="attributes-position"
            count={NODE_COUNT}
            array={positions}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.055}
          color="#8fb2ff"
          transparent
          opacity={0.85}
          sizeAttenuation
        />
      </points>
      <lineSegments ref={lineRef}>
        <bufferGeometry ref={lineGeomRef}>
          <bufferAttribute
            attach="attributes-position"
            count={maxLines * 2}
            array={linePositions}
            itemSize={3}
          />
        </bufferGeometry>
        <lineBasicMaterial
          color="#3D74FF"
          transparent
          opacity={0.18}
        />
      </lineSegments>
    </group>
  );
}

export default function ArgumentWeb() {
  const mouse = useRef<[number, number]>([0, 0]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const onMove = (e: MouseEvent) => {
      mouse.current = [
        (e.clientX / window.innerWidth) * 2 - 1,
        (e.clientY / window.innerHeight) * 2 - 1,
      ];
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  if (!mounted) return null;

  return (
    <div className="absolute inset-0 -z-10">
      <Canvas
        camera={{ position: [0, 0, 9], fov: 55 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true }}
      >
        <Web mouse={mouse} />
      </Canvas>
    </div>
  );
}
