"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { achievements } from "@/lib/data";

export default function Achievements() {
  return (
    <section id="achievements" className="section-pad relative bg-charcoal">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="eyebrow mb-4"
        >
          Achievements
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="font-display text-3xl md:text-5xl font-semibold text-porcelain mb-14 max-w-2xl"
        >
          Moments on the record
        </motion.h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((a, i) => (
            <motion.div
              key={a.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ delay: (i % 3) * 0.1, duration: 0.6 }}
              whileHover={{ y: -8 }}
              data-cursor-hover
              className="group relative rounded-2xl overflow-hidden gradient-border"
            >
              <div className="relative aspect-[4/5] overflow-hidden">
                <Image
                  src={a.image}
                  alt={`${a.title} — ${a.event}`}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-void via-void/50 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-t from-electric/0 to-violet/0 group-hover:from-electric/10 group-hover:to-violet/10 transition-all duration-500" />
              </div>

              <div className="absolute top-4 left-4">
                <span className="font-mono text-[11px] px-3 py-1 rounded-full glass-strong text-electric-soft tracking-wide">
                  {a.year}
                </span>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-5">
                <h3 className="font-display text-lg font-semibold text-white mb-1">
                  {a.title}
                </h3>
                <p className="text-xs text-mist mb-2">{a.event}</p>
                <p className="text-xs text-mist/0 group-hover:text-mist/90 max-h-0 group-hover:max-h-24 overflow-hidden transition-all duration-500 leading-relaxed">
                  {a.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
