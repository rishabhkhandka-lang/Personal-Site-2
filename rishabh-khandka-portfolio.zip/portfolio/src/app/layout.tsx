import type { Metadata } from "next";
import { JetBrains_Mono } from "next/font/google";
import "./globals.css";
import SmoothScrollProvider from "@/components/SmoothScrollProvider";
import CustomCursor from "@/components/CustomCursor";
import NoiseOverlay from "@/components/NoiseOverlay";

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://rishabhkhandka.com"),
  title: "Rishabh S. Khandka — Speaker. Strategist. Still Becoming.",
  description:
    "Founding Head Boy, award-winning debater, and public speaker exploring the intersection of discipline, strategy, and applied AI. Portfolio of Rishabh Singh Khandka.",
  keywords: [
    "Rishabh Khandka",
    "Rishabh Singh Khandka",
    "Head Boy Ann Mary School",
    "debater",
    "public speaker portfolio",
  ],
  authors: [{ name: "Rishabh Singh Khandka" }],
  openGraph: {
    title: "Rishabh S. Khandka",
    description: "Speaker. Strategist. Still becoming.",
    url: "https://rishabhkhandka.com",
    siteName: "Rishabh S. Khandka",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Rishabh S. Khandka",
    description: "Speaker. Strategist. Still becoming.",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={jetbrains.variable}>
      <head>
        <link
          href="https://api.fontshare.com/v2/css?f[]=clash-display@600,700&f[]=satoshi@400,500,600,700&display=swap"
          rel="stylesheet"
        />
        <style>{`
          :root {
            --font-clash: 'Clash Display', sans-serif;
            --font-satoshi: 'Satoshi', sans-serif;
          }
        `}</style>
      </head>
      <body>
        <NoiseOverlay />
        <CustomCursor />
        <SmoothScrollProvider>{children}</SmoothScrollProvider>
      </body>
    </html>
  );
}
